from setuptools import setup, find_packages

setup(
    name="pypatchy",
    version="0.1",
    packages=find_packages()
    # TODO: more
)
# TODO: compile TLM? i guess
